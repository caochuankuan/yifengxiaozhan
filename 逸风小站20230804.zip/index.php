<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>逸风小站</title>
    <style>
    	*{margin: 0px;padding: 0px;}
	    body{
        	    background-color: #f2f3fa;
        	    width: 1000px;
        	    margin: 0 auto;
        	    /* overflow-x: hidden; */
	    }
	    .wenzi{
        	    text-decoration: none;
        	    float: left;
        	    margin-top: 2px;
        	    font-size: 20px;
	    }
	    a{
	        text-decoration: none;
	    }
	    .header,.header a{
	        background-color: white;
	        height: 70px;
	        font-size: 40px;
	        text-align: center;
	        font-family: 华文楷体;
	    }
	    .titlea{
	        float: none;
	    }
	    .search{
	        margin: 0 auto;
	        width: 1000px;
	        height: 70px;
	        background-color: white;
	    }
	    .search input{
	        width: 850px;
	        height: 50px;
	        border-radius: 30px;
	        padding-left: 20px;
	    }
	    .search button{
	        width: 100px;
	        height: 50px;
	        border-radius: 30px;
	        background-color: #3b75fb;
	    }

	    .main{
            position: absolute;
	        width:1000px;
	        height: 300px;
	        margin: 0 auto;
	        background-color: #f2f3fa;
	    }
	    .main img{width:30px;height:30px;float: left;margin-left: 20px;margin-right: 10px;}
	    .title{
	        text-align: center;
	        font-family: 幼圆;
	        width: 1000px;
	        height: 20px;
	        margin-top: 25px;
	        margin-bottom: 10px;
	        font-size: 25px;
	    }
	    .listbox{
            position: absolute;
	        width: 1000px;
	        height: 100px;
	    }
	    .list,.listaa{
	        width: 310px;
	        height: 50px;
	        float: left;
	        border: blue 2px none;
	        border-radius: 30px;
	        text-align: center;
	        padding-top: 20px;
	        margin: 10px  10px;
	        float: left;
	        background-color: white;
	        text-overflow: hidden;
	    }
        .listaa{
            width: 1000px!important;
            /* text-align: left!important; */
            height: 45px;
        }
        .listaa a{
            font-size: 30px;
            line-height: 28px;
            padding-left: 20px;
        }
	    .list a{
            color:blue;
	        font-size: 25px;
	        line-height: 25px;
	        width: 250px;
	        height: 25px;
	        text-align: left;
	        overflow: hidden;
	        text-overflow: ellipsis;
	        white-space: nowrap;
	    }
        .list a:hover{color:skyblue;}
        .listaa a:hover{color:skyblue;}
	    .list:hover{box-shadow: 0px 0px 6px 0px #3b75fb;}
	    .listaa:hover{box-shadow: 0px 0px 6px 0px #3b75fb;}
	    .weibu{
            position: absolute;
            top: 1700px;
	        text-align: center;
	        margin-top: 50px;
	        width: 1000px;
	        height: 90px;
	        background-color:white;
	        border-radius: 85px;
            border: #3b75fb 0.5px solid;
	    }

	    .zujian{
	        width: 1000px;
	        float: left;
	        /* background-color: #3b75fb; */
	        position: absolute;
	    }
	    .showtime,.daojishi,.weather,.meiriyiyan{
	        margin: 30px 30px;
	        text-align: center;
	        width: 190px;
	        height: 160px;
	        background-color: #3b75fb;
	        font-size: 20px;
	        line-height: 40px;
	        background-color: white;
	        border-radius: 40px;
	        float: left;
	        overflow: hidden;
	        text-overflow: ellipsis;
	        white-space: nowrap;
	    }
	    .showtime:hover,.daojishi:hover,.meiriyiyan:hover,.weather:hover{
	        box-shadow: 0px 0px 6px 0px #3b75fb;
	    }
        .box_dh{
            width: 1000px;
            background-color:aqua;
            position: relative;
            z-index: 100;
            }
        .title_dh{
            width: 250px;
            height: 50px;
            float: left;
            text-align: center;
            line-height: 50px;
            background-color: white;
            border-radius: 0px 0px 50px 50px;
            cursor: pointer; /* 添加光标样式 */
            }
        .yincang{
            height: 0px;
            overflow: hidden;
            font-size: 30px;
            transition: height 0.3s ease-out; /* 添加过渡效果 */
            background-color: white;
            border-radius: 10px;
            }
        .yincang li {
            height: 50px;
            }
        .yincang li a{
            color:blue;
        }
        .yincang li a:hover{
            color:skyblue;
        }
    </style>
    <script src="js/jquery-3.6.0.js"></script>
    <script>
        $(function(){
            var flag = 0;
            $(".title_dh").click(function(){
                if(flag == 0){
                    var $yincang = $(this).find(".yincang");
                    $yincang.css("height", $yincang.get(0).scrollHeight + "px"); 
                    $(this).siblings().find(".yincang").css("height", "0px"); 
                    flag =1;
                }else if(flag ==1){
                    var $yincang = $(this).find(".yincang");
                    $yincang.css("height", "0px"); 
                    $(this).siblings().find(".yincang").css("height", "0px"); 
                    flag =0;
                }
            })
            
        })
    </script>
    <script src="js/move.js"></script>
    <script src="js/move1.js"></script>
    <script type="text/javascript" src="./tongji/getip.php"></script>
    <script src="js/showtime.js"></script>
</head>
<body>

    <!-- header start -->
    <div class="header"><a class="titlea" href="night/index1.html" title="切换动态版">逸风小站</a></div>
    <div class="search">
        <form method="GET" action="https://www.baidu.com/s" target="_blank">
        	<input type="text" placeholder="请输入内容" name="word">
        	<button type="submit">百度一下</button>
        </form>
    </div>
    <!-- header end -->

    <div class="zujian" style="top:170px;">
        <!-- time start -->
        <div class="showtime"><span id="showtime"></span></div>
        <!-- time end -->

        <!-- 倒计时 start -->
        <div class="daojishi">
            <?php
                function countDown($time){
                    $timeOver=strtotime($time);
                    echo "距离开学<br>还有<span id='countdown'></span>";
            ?>

            <script>
                function updateCountdown(){
                    // 获取当前时间和结束时间的时间戳
                    var timeNow = new Date().getTime();
                    var timeOver = new Date("<?php echo date('Y-m-d H:i:s', $timeOver); ?>").getTime();
                    // 计算倒计时时间
                    var diff = timeOver - timeNow;
                    var day = Math.floor(diff / (1000 * 60 * 60 * 24));
                    var hour = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    var minute = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                    var second = Math.floor((diff % (1000 * 60)) / 1000);
                    // 更新显示倒计时的元素
                    document.getElementById("countdown").innerHTML = day + " 天 " + "<br>"+ hour + " 小时 " + minute + " 分 " + "<br>" + second + " 秒 ";
                }
                // 定时器 每秒钟更新一次
                setInterval(updateCountdown, 1000);
            </script>
        <?php
        }
        countDown('2023-09-02 17:00:00');
        ?>
        </div>
        <!-- 倒计时 end -->

        <!-- 每日一言 start -->
        <div class="meiriyiyan">
            <?php
                // 存储数据的文件
                $filename = 'time/data.txt';        

                // 指定页面编码
                // header('Content-type: text/html; charset=utf-8');

                if(!file_exists($filename)) {
                    die($filename . ' 数据文件不存在');
                }

                // 读取整个数据文件
                $data = file_get_contents($filename);

                // 按换行符分割成数组
                $data = explode(PHP_EOL, $data);

                // 随机获取一行索引
                $result = $data[array_rand($data)];

                // 去除多余的换行符（保险起见）
                $result = str_replace(array("\r","\n","\r\n"), '', $result);

                echo $result;
            ?>
        </div>
        <!-- 每日一言 end -->

        <!-- weather start -->
        <iframe class="weather" scrolling="no" src="https://tianqiapi.com/api.php?style=tp&skin=orange" frameborder="0" width="160" height="160" allowtransparency="true"></iframe>
        <!-- weather end -->

    </div>

    <!-- 导航 start -->
    <div class="box_dh">
        <div class="title_dh">
            <div>时间</div>
            <div class="yincang">
                <ul>
                    <li>··········</li>
                  
                    <li>··········</li>
                </ul>
            </div>
        </div>
        <div class="title_dh">
            <div>倒计时</div>
            <div class="yincang">
                <ul>
                    <li>··········</li>
                  
                    <li>··········</li>
                </ul>
            </div>
        </div>
        <div class="title_dh">
            <div>一言</div>
            <div class="yincang">
                <ul>
                    <li>··········</li>
                    <li><a href="http://47.120.3.2:5244/">逸风小站</a></li>
                   
                    <li>··········</li>
                </ul>
            </div>
        </div>
        <div class="title_dh">
            <div>天气</div>
            <div class="yincang">
                <ul>
                    <li>··········</li>
                    <li><a href="http://chuankuan.top/fly_bird/">飞翔的小鸟</a></li>
                    <li>··········</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- 导航 end -->

    <!-- 主体部分 start -->
    <div class="zhuti" style="padding-top: 225px;">
        <div class="main">
            <div class="title">案例</div>
            <div class="listbox">
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="yinshi/sy.html" title="yifeng" target="_blank">演示影视</a></div>
                <div class="list"><img src="images/w3c.png"/><a class="wenzi" href="w3school/html-main.html" title="yifeng" target="_blank">演示框架</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="yinyue/yifengmusic.html" title="yifeng" target="_blank">演示音乐</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="program/lbt" title="yifeng" target="_blank">轮播图</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="program/bird" title="yifeng" target="_blank">飞翔的小鸟</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="program/zkscd" title="yifeng" target="_blank">点击式展开</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="program/dhsxs" title="yifeng" target="_blank">导航式显示</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="program/jscss" title="yifeng" target="_blank">jQuery的点击事件与CSS的hover</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="program/get" title="yifeng" target="_blank">GET请求提交表单</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="program/yzm" title="yifeng" target="_blank">验证码</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="program/tpcz" title="yifeng" target="_blank">图片操作</a></div>
                <div class="list"><img src="images/ico.png"/><a class="wenzi" href="program/wjxz" title="yifeng" target="_blank">PHP之文件下载</a></div>

            </div>
        </div>

        <div class="main" style="margin-top: 420px;">
            <div class="title">案例源码</div>
            <div class="listbox">
                <div class="listaa"><a href="program/lbt/lbt.html">1.轮播图（通过jQuery实现）</a></div>
                <div class="listaa"><a href="program/bird/bird.html">2.飞翔的小鸟（纯前端实现）</a></div>
                <div class="listaa"><a href="program/zkscd/zkscd.html">3.点击式展开（vue实现）</a></div>
                <div class="listaa"><a href="program/dhsxs/dhsxs.html">4.导航式显示（通过jQuery实现）</a></div>
                <div class="listaa"><a href="program/jscss/jscss.html">5.jQuery的点击事件与CSS的hover</a></div>
                <div class="listaa"><a href="program/get/get.html">6.GET请求提交表单</a></div>
                <div class="listaa"><a href="program/zzbds/zzbds.html">7.PHP常用正则表达式大全</a></div>
                <div class="listaa"><a href="program/yzm/yzm.html">8.验证码（需开启GD库）</a></div>
                <div class="listaa"><a href="program/tpcz/tpcz.html">9.PHP之图片操作</a></div>
                <div class="listaa"><a href="program/wjxz/wjxz.html">10.PHP之文件下载</a></div>

            </div>
        </div>

       
  
    </div>
    <!-- 主体部分 end -->

    <!-- footer start -->
    <div class="weibu">
        <div class="icp"><a style="color:#000;" href="https://beian.miit.gov.cn">粤ICP备2023050418号</a></div>
        <div class="tongji">你是第<script type="text/javascript" src="./tongji/FKTJ.php"></script>位访问者(访问量)</div>
        <div class="banquan">联系方式：2835082172@qq.com<br>本站内容部分来自网络，如有侵权等问题，请联系管理员删除。</div>
    </div>
    <!-- footer end -->
</body>
</html>
